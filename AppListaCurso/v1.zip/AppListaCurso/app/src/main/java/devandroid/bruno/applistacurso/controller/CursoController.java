package devandroid.bruno.applistacurso.controller;

public class CursoController {
}
